import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as CalendarClock, i as Minus, n as SlidersHorizontal, r as Plus } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BiMKwina.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BRANDS = [{
	id: "inka",
	name: "Inka Express",
	mark: "IE"
}, {
	id: "rmt",
	name: "RMT",
	mark: "R"
}];
var BRAND_NAME = {
	inka: "Inka Express",
	rmt: "RMT"
};
var MONTHS = [
	"ene",
	"feb",
	"mar",
	"abr",
	"may",
	"jun",
	"jul",
	"ago",
	"sep",
	"oct",
	"nov",
	"dic"
];
var WEEKDAYS = [
	"domingo",
	"lunes",
	"martes",
	"miércoles",
	"jueves",
	"viernes",
	"sábado"
];
var STORAGE_KEY = "cardex-agua-v1";
var MAX_PACKS = 1e5;
function isBrand(value) {
	return value === "inka" || value === "rmt";
}
function isISODate(value) {
	if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
	const y = Number(value.slice(0, 4));
	const m = Number(value.slice(5, 7));
	const d = Number(value.slice(8, 10));
	if (m < 1 || m > 12 || d < 1 || d > 31) return false;
	const dt = new Date(Date.UTC(y, m - 1, d));
	return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}
function localISODate(date) {
	return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function addDaysISO(iso, days) {
	const y = Number(iso.slice(0, 4));
	const m = Number(iso.slice(5, 7));
	const d = Number(iso.slice(8, 10));
	const dt = new Date(Date.UTC(y, m - 1, d + days));
	return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, "0")}-${String(dt.getUTCDate()).padStart(2, "0")}`;
}
function weekdayISO(iso) {
	const y = Number(iso.slice(0, 4));
	const m = Number(iso.slice(5, 7));
	const d = Number(iso.slice(8, 10));
	return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}
function diffDays(from, to) {
	const a = Date.UTC(Number(from.slice(0, 4)), Number(from.slice(5, 7)) - 1, Number(from.slice(8, 10)));
	const b = Date.UTC(Number(to.slice(0, 4)), Number(to.slice(5, 7)) - 1, Number(to.slice(8, 10)));
	return Math.round((b - a) / 864e5);
}
function formatQty(n) {
	return new Intl.NumberFormat("es-PE", { maximumFractionDigits: 0 }).format(Math.round(n));
}
function formatShort(iso) {
	const d = Number(iso.slice(8, 10));
	const m = Number(iso.slice(5, 7));
	const y = iso.slice(0, 4);
	return `${d} ${MONTHS[m - 1]} ${y}`;
}
function formatHeadingDate(iso) {
	const d = Number(iso.slice(8, 10));
	const m = Number(iso.slice(5, 7));
	const label = `${WEEKDAYS[weekdayISO(iso)]} ${d} ${MONTHS[m - 1]}`;
	return label.charAt(0).toUpperCase() + label.slice(1);
}
function bottlesOf(packages) {
	return packages * 15;
}
function relativeFuture(from, to) {
	const n = diffDays(from, to);
	if (n <= 0) return "Hoy";
	if (n === 1) return "Mañana";
	return `En ${n} días`;
}
function listMondaysAfter(opening, through) {
	if (!isISODate(opening) || !isISODate(through) || through <= opening) return [];
	let date = addDaysISO(opening, 1);
	for (let i = 0; i < 7 && weekdayISO(date) !== 1; i += 1) date = addDaysISO(date, 1);
	const dates = [];
	while (date <= through && dates.length < 300) {
		dates.push(date);
		date = addDaysISO(date, 7);
	}
	return dates;
}
function nextAutoMonday(today, opening) {
	let date = addDaysISO(today > opening ? today : opening, 1);
	for (let i = 0; i < 7 && weekdayISO(date) !== 1; i += 1) date = addDaysISO(date, 1);
	return date;
}
function defaultStore(today) {
	return {
		settings: {
			openingDate: today,
			initial: {
				inka: 200,
				rmt: 70
			},
			weekly: {
				inka: 50,
				rmt: 20
			}
		},
		manuals: [],
		mondays: [],
		skipped: []
	};
}
function clampPacks(value, fallback) {
	const n = typeof value === "number" ? value : Number(value);
	if (!Number.isFinite(n)) return fallback;
	return Math.min(MAX_PACKS, Math.max(0, Math.round(n)));
}
function mondayKey(brand, date) {
	return `${brand}|${date}`;
}
function isPostableMonday(date, opening, today) {
	return isISODate(date) && date > opening && date <= today && weekdayISO(date) === 1;
}
function sameMondays(a, b) {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i += 1) if (a[i].brand !== b[i].brand || a[i].date !== b[i].date || a[i].packages !== b[i].packages) return false;
	return true;
}
function sameStrings(a, b) {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i += 1) if (a[i] !== b[i]) return false;
	return true;
}
function withReconciledMondays(store, today) {
	const opening = store.settings.openingDate;
	const map = /* @__PURE__ */ new Map();
	for (const entry of store.mondays) {
		if (!isBrand(entry.brand) || !isPostableMonday(entry.date, opening, today)) continue;
		map.set(mondayKey(entry.brand, entry.date), {
			brand: entry.brand,
			date: entry.date,
			packages: clampPacks(entry.packages, 0)
		});
	}
	const skipped = store.skipped.filter((key) => {
		const brand = key.slice(0, key.indexOf("|"));
		const date = key.slice(key.indexOf("|") + 1);
		return isBrand(brand) && isPostableMonday(date, opening, today);
	}).sort();
	for (const brand of BRANDS) for (const date of listMondaysAfter(opening, today)) {
		const key = mondayKey(brand.id, date);
		if (map.has(key) || skipped.includes(key)) continue;
		const packages = store.settings.weekly[brand.id];
		if (packages <= 0) continue;
		map.set(key, {
			brand: brand.id,
			date,
			packages
		});
	}
	const mondays = [...map.values()].sort((a, b) => a.date === b.date ? a.brand.localeCompare(b.brand) : a.date < b.date ? -1 : 1);
	if (sameMondays(mondays, store.mondays) && sameStrings(skipped, store.skipped)) return store;
	return {
		...store,
		mondays,
		skipped
	};
}
function parseManual(value) {
	if (!value || typeof value !== "object") return null;
	const row = value;
	if (!isBrand(row.brand) || row.kind !== "ingreso" && row.kind !== "salida" || !isISODate(row.date)) return null;
	const packages = clampPacks(row.packages, 0);
	if (packages < 1) return null;
	const concept = typeof row.concept === "string" && row.concept.trim() ? row.concept.trim().slice(0, 80) : row.kind === "ingreso" ? "Ingreso adicional" : "Salida de almacén";
	return {
		id: typeof row.id === "string" && row.id ? row.id : crypto.randomUUID(),
		createdAt: typeof row.createdAt === "number" && Number.isFinite(row.createdAt) ? row.createdAt : 0,
		date: row.date,
		brand: row.brand,
		kind: row.kind,
		packages,
		concept
	};
}
function sanitizeStore(value, today) {
	const base = defaultStore(today);
	if (!value || typeof value !== "object") return base;
	const raw = value;
	const settingsRaw = raw.settings && typeof raw.settings === "object" ? raw.settings : {};
	const initialRaw = settingsRaw.initial && typeof settingsRaw.initial === "object" ? settingsRaw.initial : {};
	const weeklyRaw = settingsRaw.weekly && typeof settingsRaw.weekly === "object" ? settingsRaw.weekly : {};
	const settings = {
		openingDate: isISODate(settingsRaw.openingDate) ? settingsRaw.openingDate : today,
		initial: {
			inka: clampPacks(initialRaw.inka, base.settings.initial.inka),
			rmt: clampPacks(initialRaw.rmt, base.settings.initial.rmt)
		},
		weekly: {
			inka: clampPacks(weeklyRaw.inka, base.settings.weekly.inka),
			rmt: clampPacks(weeklyRaw.rmt, base.settings.weekly.rmt)
		}
	};
	const manuals = Array.isArray(raw.manuals) ? raw.manuals.flatMap((row) => {
		const parsed = parseManual(row);
		return parsed ? [parsed] : [];
	}) : [];
	const seen = /* @__PURE__ */ new Set();
	return {
		settings,
		manuals: manuals.filter((row) => {
			if (seen.has(row.id)) return false;
			seen.add(row.id);
			return true;
		}),
		mondays: Array.isArray(raw.mondays) ? raw.mondays.flatMap((row) => {
			if (!row || typeof row !== "object") return [];
			const entry = row;
			if (!isBrand(entry.brand) || !isISODate(entry.date)) return [];
			return [{
				brand: entry.brand,
				date: entry.date,
				packages: clampPacks(entry.packages, 0)
			}];
		}) : [],
		skipped: Array.isArray(raw.skipped) ? raw.skipped.filter((key) => typeof key === "string") : []
	};
}
function loadStore(today) {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return defaultStore(today);
		return sanitizeStore(JSON.parse(raw), today);
	} catch {
		return defaultStore(today);
	}
}
function saveStore(store) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
	} catch {}
}
var KIND_ORDER = {
	inicial: 0,
	lunes: 1,
	ingreso: 2,
	salida: 3
};
function buildLedger(store, brand) {
	const rows = [{
		id: `inicial:${brand}`,
		date: store.settings.openingDate,
		brand,
		kind: "inicial",
		concept: "Inventario inicial",
		entrada: store.settings.initial[brand],
		salida: 0,
		auto: true
	}];
	for (const entry of store.mondays) {
		if (entry.brand !== brand || store.skipped.includes(mondayKey(brand, entry.date))) continue;
		rows.push({
			id: `lunes:${brand}:${entry.date}`,
			date: entry.date,
			brand,
			kind: "lunes",
			concept: "Ingreso de lunes",
			entrada: entry.packages,
			salida: 0,
			auto: true
		});
	}
	for (const manual of store.manuals) {
		if (manual.brand !== brand) continue;
		rows.push({
			id: manual.id,
			date: manual.date,
			brand,
			kind: manual.kind,
			concept: manual.concept,
			entrada: manual.kind === "ingreso" ? manual.packages : 0,
			salida: manual.kind === "salida" ? manual.packages : 0,
			auto: false,
			manualId: manual.id
		});
	}
	rows.sort((a, b) => {
		if (a.date !== b.date) return a.date < b.date ? -1 : 1;
		if (KIND_ORDER[a.kind] !== KIND_ORDER[b.kind]) return KIND_ORDER[a.kind] - KIND_ORDER[b.kind];
		return a.id < b.id ? -1 : 1;
	});
	let saldo = 0;
	return rows.map((row) => {
		saldo += row.entrada - row.salida;
		return {
			...row,
			saldo
		};
	});
}
function totalsAsOf(rows, today) {
	let entrada = 0;
	let salida = 0;
	for (const row of rows) {
		if (row.date > today) continue;
		entrada += row.entrada;
		salida += row.salida;
	}
	return {
		entrada,
		salida,
		stock: entrada - salida
	};
}
function skippedFor(store, brand) {
	return store.mondays.filter((entry) => entry.brand === brand && store.skipped.includes(mondayKey(brand, entry.date))).sort((a, b) => a.date < b.date ? -1 : 1);
}
function balanceProblem(store) {
	for (const brand of BRANDS) {
		const bad = buildLedger(store, brand.id).find((row) => row.saldo < 0);
		if (bad) return `El saldo de ${BRAND_NAME[brand.id]} quedaría en ${formatQty(bad.saldo)} paquetes el ${formatShort(bad.date)}.`;
	}
	return null;
}
function addManual(store, input, today) {
	if (!Number.isInteger(input.packages) || input.packages < 1 || input.packages > MAX_PACKS) return {
		ok: false,
		error: "Indica los paquetes con un número entero, de 1 a 100000."
	};
	if (!isISODate(input.date)) return {
		ok: false,
		error: "La fecha no es válida."
	};
	if (input.date < store.settings.openingDate) return {
		ok: false,
		error: "La fecha es anterior al inventario inicial."
	};
	if (input.date > today) return {
		ok: false,
		error: "Esa fecha todavía no llega. El lote del lunes se anota solo."
	};
	const concept = input.concept.trim().slice(0, 80) || (input.kind === "ingreso" ? "Ingreso adicional" : "Salida de almacén");
	const next = {
		...store,
		manuals: [...store.manuals, {
			id: crypto.randomUUID(),
			createdAt: Date.now(),
			date: input.date,
			brand: input.brand,
			kind: input.kind,
			packages: input.packages,
			concept
		}]
	};
	const error = balanceProblem(next);
	if (error) return {
		ok: false,
		error: input.kind === "salida" ? `No hay saldo suficiente. ${error}` : error
	};
	return {
		ok: true,
		store: next
	};
}
function removeManual(store, id) {
	const next = {
		...store,
		manuals: store.manuals.filter((row) => row.id !== id)
	};
	const error = balanceProblem(next);
	if (error) return {
		ok: false,
		error
	};
	return {
		ok: true,
		store: next
	};
}
function skipMonday(store, brand, date, today) {
	if (!isPostableMonday(date, store.settings.openingDate, today)) return {
		ok: false,
		error: "Ese lunes todavía no entra al cardex."
	};
	const key = mondayKey(brand, date);
	let mondays = store.mondays;
	if (!mondays.some((entry) => entry.brand === brand && entry.date === date)) {
		const packages = store.settings.weekly[brand];
		if (packages <= 0) return {
			ok: false,
			error: "Ese lunes no tiene paquetes anotados."
		};
		mondays = [...mondays, {
			brand,
			date,
			packages
		}];
	}
	const skipped = store.skipped.includes(key) ? store.skipped : [...store.skipped, key];
	const next = withReconciledMondays({
		...store,
		mondays,
		skipped
	}, today);
	const error = balanceProblem(next);
	if (error) return {
		ok: false,
		error
	};
	return {
		ok: true,
		store: next
	};
}
function restoreMonday(store, brand, date, today) {
	const key = mondayKey(brand, date);
	const next = withReconciledMondays({
		...store,
		skipped: store.skipped.filter((item) => item !== key)
	}, today);
	const error = balanceProblem(next);
	if (error) return {
		ok: false,
		error
	};
	return {
		ok: true,
		store: next
	};
}
function applySettings(store, settings, today) {
	if (!isISODate(settings.openingDate)) return {
		ok: false,
		error: "La fecha inicial no es válida."
	};
	if (diffDays(settings.openingDate, today) > 1820) return {
		ok: false,
		error: "La fecha inicial no puede tener más de 5 años."
	};
	if (diffDays(today, settings.openingDate) > 366) return {
		ok: false,
		error: "La fecha inicial no puede pasar de un año."
	};
	const early = store.manuals.find((row) => row.date < settings.openingDate);
	if (early) return {
		ok: false,
		error: `Hay un movimiento del ${formatShort(early.date)}, antes de esa fecha.`
	};
	const clean = {
		openingDate: settings.openingDate,
		initial: {
			inka: clampPacks(settings.initial.inka, 0),
			rmt: clampPacks(settings.initial.rmt, 0)
		},
		weekly: {
			inka: clampPacks(settings.weekly.inka, 0),
			rmt: clampPacks(settings.weekly.rmt, 0)
		}
	};
	const next = withReconciledMondays({
		...store,
		settings: clean
	}, today);
	const error = balanceProblem(next);
	if (error) return {
		ok: false,
		error
	};
	return {
		ok: true,
		store: next
	};
}
function cx(...parts) {
	return parts.filter(Boolean).join(" ");
}
function CardexApp() {
	const [today, setToday] = (0, import_react.useState)(null);
	const [store, setStore] = (0, import_react.useState)(null);
	const [dialog, setDialog] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const current = localISODate(/* @__PURE__ */ new Date());
		setToday(current);
		setStore(withReconciledMondays(loadStore(current), current));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!today || !store) return;
		const next = withReconciledMondays(store, today);
		if (next !== store) setStore(next);
	}, [store, today]);
	(0, import_react.useEffect)(() => {
		if (!store || !today) return;
		saveStore(store);
	}, [store, today]);
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const current = localISODate(/* @__PURE__ */ new Date());
			setToday((prev) => prev === current ? prev : current);
		};
		const id = window.setInterval(tick, 6e4);
		document.addEventListener("visibilitychange", tick);
		return () => {
			window.clearInterval(id);
			document.removeEventListener("visibilitychange", tick);
		};
	}, []);
	if (!today || !store) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-6xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold tracking-wide text-lagoon uppercase",
				children: "Almacén de agua"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-4xl text-ink",
				children: "Cardex de ingreso"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xl text-muted",
				children: "Cargando paquetes de Inka Express y RMT."
			})
		]
	});
	const ledgers = BRANDS.map((brand) => {
		const rows = buildLedger(store, brand.id);
		return {
			brand,
			rows,
			totals: totalsAsOf(rows, today)
		};
	});
	const stockPacks = ledgers.reduce((sum, item) => sum + item.totals.stock, 0);
	const stockBottles = bottlesOf(stockPacks);
	const opening = store.settings.openingDate;
	const received = opening <= today;
	const upcoming = nextAutoMonday(today, opening);
	const initialIsNext = opening > today;
	function apply(result) {
		if (!result.ok) return result.error;
		setStore(result.store);
		setNotice(null);
		setDialog(null);
		return null;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen max-w-6xl px-4 py-6 sm:px-6 sm:py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-wide text-lagoon uppercase",
						children: "Almacén de agua"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-4xl text-ink sm:text-5xl",
						children: "Cardex de ingreso"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 max-w-2xl text-muted",
						children: [
							"Partimos con ",
							formatQty(store.settings.initial.inka),
							" paquetes de Inka Express y",
							" ",
							formatQty(store.settings.initial.rmt),
							" de RMT el ",
							formatShort(opening),
							". Desde el lunes siguiente entran",
							" ",
							formatQty(store.settings.weekly.inka),
							" y ",
							formatQty(store.settings.weekly.rmt),
							" cada semana. Cada paquete trae",
							" ",
							15,
							" botellas."
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2 sm:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setNotice(null);
							setDialog({ type: "settings" });
						},
						className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-line bg-card px-4 text-sm font-semibold text-ink hover:bg-paper",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Ajustar regla"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							setNotice(null);
							setDialog({
								type: "move",
								kind: "ingreso",
								brand: "inka"
							});
						},
						disabled: !received,
						className: "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-lagoon px-4 text-sm font-semibold text-on-lagoon hover:bg-lagoon-deep disabled:opacity-50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Registrar ingreso"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-card bg-lagoon p-5 text-on-lagoon shadow-card lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold tracking-wide text-on-lagoon-muted uppercase",
							children: received ? "En almacén" : "Por recibir"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-display text-5xl leading-none tabular-nums sm:text-6xl",
							children: formatQty(received ? stockBottles : bottlesOf(store.settings.initial.inka + store.settings.initial.rmt))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-on-lagoon-muted",
							children: received ? `${formatQty(stockPacks)} paquetes · 15 botellas cada uno` : `Llegan el ${formatShort(opening)} · todavía no están en almacén`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "mt-5 grid gap-3 sm:grid-cols-2",
							children: ledgers.map(({ brand, totals }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 border-t border-lagoon-line pt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid size-11 shrink-0 place-items-center rounded-xl bg-lagoon-deep font-display text-lg text-on-lagoon",
									children: brand.mark
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "font-semibold",
										children: brand.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "text-sm text-on-lagoon-muted tabular-nums",
										children: received ? `${formatQty(totals.stock)} paquetes · ${formatQty(bottlesOf(totals.stock))} botellas` : `${formatQty(store.settings.initial[brand.id])} paquetes al llegar`
									})]
								})]
							}, brand.id))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "flex flex-col justify-between rounded-card border border-line bg-card p-5 shadow-card",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-11 place-items-center rounded-xl bg-clay-soft text-clay",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, {
									className: "size-5",
									"aria-hidden": "true"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold tracking-wide text-clay uppercase",
								children: initialIsNext ? "Próximo movimiento" : "Cada lunes"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-3xl text-ink",
							children: initialIsNext ? formatHeadingDate(opening) : formatHeadingDate(upcoming)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: relativeFuture(today, initialIsNext ? opening : upcoming)
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-2 text-sm",
						children: [initialIsNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-ink",
							children: [
								"Entra el inventario inicial: ",
								formatQty(store.settings.initial.inka),
								" paquetes de Inka Express y",
								" ",
								formatQty(store.settings.initial.rmt),
								" de RMT."
							]
						}) : BRANDS.map((brand) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-baseline justify-between gap-3 tabular-nums",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-ink",
								children: brand.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-lagoon",
								children: [
									"+",
									formatQty(store.settings.weekly[brand.id]),
									" paq",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "mt-0.5 block text-right text-xs font-medium text-muted",
										children: [formatQty(bottlesOf(store.settings.weekly[brand.id])), " bot."]
									})
								]
							})]
						}, brand.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: initialIsNext ? "Después, cada lunes se suma solo el lote semanal." : "Si no abres el cardex un lunes, el lote queda anotado cuando vuelvas."
						})]
					})]
				})]
			}),
			notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-4 rounded-xl bg-danger-soft px-4 py-3 text-sm text-danger",
				children: notice
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-4 lg:grid-cols-2",
				children: ledgers.map(({ brand, rows, totals }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandCard, {
					brandId: brand.id,
					name: brand.name,
					mark: brand.mark,
					rows,
					stock: totals.stock,
					entered: totals.entrada,
					left: totals.salida,
					weekly: store.settings.weekly[brand.id],
					today,
					skipped: skippedFor(store, brand.id),
					received,
					onMove: (kind) => {
						setNotice(null);
						setDialog({
							type: "move",
							kind,
							brand: brand.id
						});
					},
					onSkip: (date) => {
						setNotice(null);
						setDialog({
							type: "skip",
							brand: brand.id,
							date
						});
					},
					onDelete: (id, concept) => {
						setNotice(null);
						setDialog({
							type: "delete",
							id,
							concept
						});
					},
					onRestore: (date) => {
						const result = restoreMonday(store, brand.id, date, today);
						if (!result.ok) setNotice(result.error);
						else setStore(result.store);
					}
				}, brand.id))
			}),
			dialog?.type === "move" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoveDialog, {
				store,
				today,
				initialKind: dialog.kind,
				initialBrand: dialog.brand,
				onClose: () => setDialog(null),
				onSave: (input) => apply(addManual(store, input, today))
			}) : null,
			dialog?.type === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsDialog, {
				store,
				today,
				onClose: () => setDialog(null),
				onSave: (settings) => apply(applySettings(store, settings, today)),
				onReset: () => {
					setStore(defaultStore(today));
					setNotice(null);
					setDialog(null);
				}
			}) : null,
			dialog?.type === "skip" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				title: "Quitar el ingreso de este lunes",
				body: `Se descuenta el lote del ${formatShort(dialog.date)}. Puedes restaurarlo después.`,
				confirmLabel: "Quitar lote",
				onClose: () => setDialog(null),
				onConfirm: () => apply(skipMonday(store, dialog.brand, dialog.date, today))
			}) : null,
			dialog?.type === "delete" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				title: "Quitar movimiento",
				body: `Se borra «${dialog.concept}» del cardex.`,
				confirmLabel: "Quitar",
				onClose: () => setDialog(null),
				onConfirm: () => apply(removeManual(store, dialog.id))
			}) : null
		]
	});
}
function BrandCard({ brandId, name, mark, rows, stock, entered, left, weekly, today, skipped, received, onMove, onSkip, onDelete, onRestore }) {
	const tone = brandId === "inka";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-card border border-line bg-card shadow-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cx("h-1.5", tone ? "bg-lagoon" : "bg-clay") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3 px-4 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cx("grid size-11 place-items-center rounded-xl font-display text-lg", tone ? "bg-lagoon-soft text-lagoon" : "bg-clay-soft text-clay"),
						children: mark
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl text-ink",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-wide text-muted uppercase",
						children: weekly > 0 ? `+${formatQty(weekly)} paquetes cada lunes` : "Sin lote semanal"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl leading-none tabular-nums text-ink",
						children: formatQty(received ? stock : 0)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted tabular-nums",
						children: [formatQty(bottlesOf(received ? stock : 0)), " botellas"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex gap-2 px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: !received,
					onClick: () => onMove("ingreso"),
					className: "inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl bg-lagoon px-3 text-sm font-semibold text-on-lagoon hover:bg-lagoon-deep disabled:opacity-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "size-4",
						"aria-hidden": "true"
					}), "Ingreso"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: !received || stock <= 0,
					onClick: () => onMove("salida"),
					className: "inline-flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl border border-line bg-card px-3 text-sm font-semibold text-ink hover:bg-paper disabled:opacity-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
						className: "size-4",
						"aria-hidden": "true"
					}), "Salida"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-3 gap-2 px-4 text-xs font-semibold tracking-wide text-muted uppercase",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Entra" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sale" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-right",
						children: "Saldo"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-1 max-h-80 overflow-auto",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-t border-line px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-ink",
								children: row.concept
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "shrink-0 text-sm text-muted",
								children: formatShort(row.date)
							})]
						}),
						row.date > today ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs font-semibold tracking-wide text-clay uppercase",
							children: "Programado"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Qty, {
									value: row.entrada,
									sign: "+",
									tone: "in",
									label: "Entrada"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Qty, {
									value: row.salida,
									sign: "−",
									tone: "out",
									label: "Salida"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Qty, {
									value: row.saldo,
									tone: "bal",
									label: "Saldo",
									align: "right"
								})
							]
						}),
						row.kind === "lunes" && row.date <= today ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onSkip(row.date),
							className: "mt-2 min-h-11 text-sm font-semibold text-clay",
							children: "Este lunes no llegó"
						}) : null,
						row.manualId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onDelete(row.manualId, row.concept),
							className: "mt-2 min-h-11 text-sm font-semibold text-danger",
							children: "Quitar movimiento"
						}) : null
					]
				}, row.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 border-t border-line px-4 py-3 text-sm text-muted tabular-nums",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Ingresados ", formatQty(entered)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Salidas ", formatQty(left)] })]
			}),
			skipped.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-line bg-paper px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-wide text-muted uppercase",
					children: "Lunes que no llegaron"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 space-y-2",
					children: skipped.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-ink",
							children: [
								formatShort(entry.date),
								" · ",
								formatQty(entry.packages),
								" paq"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onRestore(entry.date),
							className: "min-h-11 font-semibold text-lagoon",
							children: "Restaurar"
						})]
					}, entry.date))
				})]
			}) : null
		]
	});
}
function Qty({ value, sign = "", tone, label, align = "left" }) {
	const show = tone === "bal" || value > 0;
	const color = tone === "in" ? "text-lagoon" : tone === "out" ? "text-clay" : "text-ink";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cx(align === "right" && "text-right"),
		"aria-label": show ? `${label}: ${value} paquetes, ${bottlesOf(value)} botellas` : `${label}: ninguna`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: cx("text-sm font-semibold tabular-nums", show ? color : "text-muted"),
			children: [show ? `${sign}${formatQty(value)}` : "—", show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium text-muted",
				children: " paq"
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted tabular-nums",
			children: show ? `${formatQty(bottlesOf(value))} bot.` : "\xA0"
		})]
	});
}
function MoveDialog({ store, today, initialKind, initialBrand, onClose, onSave }) {
	const baseId = (0, import_react.useId)();
	const [kind, setKind] = (0, import_react.useState)(initialKind);
	const [brand, setBrand] = (0, import_react.useState)(initialBrand);
	const [date, setDate] = (0, import_react.useState)(today);
	const [packages, setPackages] = (0, import_react.useState)("");
	const [concept, setConcept] = (0, import_react.useState)(initialKind === "ingreso" ? "Ingreso adicional" : "Salida de almacén");
	const [error, setError] = (0, import_react.useState)(null);
	const count = /^\d+$/.test(packages) ? Number(packages) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogShell, {
		title: kind === "ingreso" ? "Registrar ingreso" : "Registrar salida",
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (event) => {
				event.preventDefault();
				const amount = /^\d+$/.test(packages) ? Number(packages) : NaN;
				const message = onSave({
					brand,
					kind,
					date,
					packages: amount,
					concept
				});
				if (message) setError(message);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 rounded-xl bg-paper p-1",
					children: ["ingreso", "salida"].map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": kind === option,
						onClick: () => {
							setKind(option);
							setConcept((current) => {
								if (current === "Ingreso adicional" || current === "Salida de almacén" || current.trim() === "") return option === "ingreso" ? "Ingreso adicional" : "Salida de almacén";
								return current;
							});
						},
						className: cx("min-h-11 rounded-lg text-sm font-semibold", kind === option ? "bg-lagoon text-on-lagoon" : "text-muted"),
						children: option === "ingreso" ? "Ingreso" : "Salida"
					}, option))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "mt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-sm font-medium text-ink",
						children: "Marca"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 grid grid-cols-2 gap-2",
						children: BRANDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-pressed": brand === item.id,
							onClick: () => setBrand(item.id),
							className: cx("min-h-11 rounded-xl border px-3 text-sm font-semibold", brand === item.id ? item.id === "inka" ? "border-lagoon bg-lagoon-soft text-lagoon" : "border-clay bg-clay-soft text-clay" : "border-line bg-card text-ink"),
							children: item.name
						}, item.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-sm font-medium text-ink",
					htmlFor: `${baseId}-date`,
					children: ["Fecha", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: `${baseId}-date`,
						type: "date",
						required: true,
						min: store.settings.openingDate,
						max: today,
						value: date,
						onChange: (event) => setDate(event.target.value),
						className: "mt-1 h-11 w-full min-w-0 max-w-full rounded-xl border border-line bg-card px-3 text-base text-ink"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-sm font-medium text-ink",
							htmlFor: `${baseId}-packs`,
							children: "Paquetes"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "grid size-11 place-items-center rounded-xl border border-line bg-card text-ink",
									onClick: () => setPackages((current) => stepPacks(current, -1)),
									"aria-label": "Un paquete menos",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
										className: "size-4",
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									id: `${baseId}-packs`,
									inputMode: "numeric",
									value: packages,
									placeholder: "0",
									onChange: (event) => setPackages(event.target.value.replace(/\D/g, "").slice(0, 6)),
									className: "h-11 min-w-0 flex-1 rounded-xl border border-line bg-card px-3 text-center font-display text-2xl text-ink tabular-nums"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "grid size-11 place-items-center rounded-xl border border-line bg-card text-ink",
									onClick: () => setPackages((current) => stepPacks(current, 1)),
									"aria-label": "Un paquete más",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
										className: "size-4",
										"aria-hidden": "true"
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted tabular-nums",
							children: count > 0 ? `${formatQty(count)} paquetes = ${formatQty(bottlesOf(count))} botellas` : `Cada paquete son 15 botellas.`
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-sm font-medium text-ink",
					htmlFor: `${baseId}-concept`,
					children: ["Concepto", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: `${baseId}-concept`,
						value: concept,
						maxLength: 80,
						onChange: (event) => setConcept(event.target.value),
						className: "mt-1 h-11 w-full rounded-xl border border-line bg-card px-3 text-base text-ink"
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "mt-3 text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "min-h-11 flex-1 rounded-xl border border-line bg-card text-sm font-semibold text-ink",
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-11 flex-1 rounded-xl bg-lagoon text-sm font-semibold text-on-lagoon hover:bg-lagoon-deep",
						children: "Guardar"
					})]
				})
			]
		})
	});
}
function stepPacks(current, delta) {
	const n = /^\d+$/.test(current) ? Number(current) : 0;
	const next = Math.min(1e5, Math.max(0, n + delta));
	return next === 0 ? "" : String(next);
}
function SettingsDialog({ store, today, onClose, onSave, onReset }) {
	const baseId = (0, import_react.useId)();
	const [openingDate, setOpeningDate] = (0, import_react.useState)(store.settings.openingDate);
	const [inkaInitial, setInkaInitial] = (0, import_react.useState)(String(store.settings.initial.inka));
	const [rmtInitial, setRmtInitial] = (0, import_react.useState)(String(store.settings.initial.rmt));
	const [inkaWeekly, setInkaWeekly] = (0, import_react.useState)(String(store.settings.weekly.inka));
	const [rmtWeekly, setRmtWeekly] = (0, import_react.useState)(String(store.settings.weekly.rmt));
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const mondayCount = listMondaysAfter(openingDate, today).length;
	function readCount(raw) {
		return /^\d+$/.test(raw) ? Number(raw) : NaN;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogShell, {
		title: "Regla del cardex",
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: (event) => {
				event.preventDefault();
				const settings = {
					openingDate,
					initial: {
						inka: readCount(inkaInitial),
						rmt: readCount(rmtInitial)
					},
					weekly: {
						inka: readCount(inkaWeekly),
						rmt: readCount(rmtWeekly)
					}
				};
				if ([
					settings.initial.inka,
					settings.initial.rmt,
					settings.weekly.inka,
					settings.weekly.rmt
				].some((n) => !Number.isInteger(n))) {
					setError("Usa números enteros en los paquetes. Cero está permitido.");
					return;
				}
				const message = onSave(settings);
				if (message) setError(message);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "El inventario inicial es la apertura. Los lunes posteriores se cargan solos y conservan la cantidad con la que entraron."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 block text-sm font-medium text-ink",
					htmlFor: `${baseId}-open`,
					children: ["Fecha del inventario inicial", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: `${baseId}-open`,
						type: "date",
						required: true,
						value: openingDate,
						onChange: (event) => setOpeningDate(event.target.value),
						className: "mt-1 h-11 w-full min-w-0 max-w-full rounded-xl border border-line bg-card px-3 text-base text-ink"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: mondayCount === 0 ? "Todavía no hay un lunes posterior a esa fecha." : `Hay ${formatQty(mondayCount)} ${mondayCount === 1 ? "lunes posterior" : "lunes posteriores"} a esa fecha.`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							id: `${baseId}-ii`,
							label: "Inicial Inka Express",
							value: inkaInitial,
							onChange: setInkaInitial
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							id: `${baseId}-ri`,
							label: "Inicial RMT",
							value: rmtInitial,
							onChange: setRmtInitial
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							id: `${baseId}-iw`,
							label: "Cada lunes Inka Express",
							value: inkaWeekly,
							onChange: setInkaWeekly
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberField, {
							id: `${baseId}-rw`,
							label: "Cada lunes RMT",
							value: rmtWeekly,
							onChange: setRmtWeekly
						})
					]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "mt-3 text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "min-h-11 flex-1 rounded-xl border border-line bg-card text-sm font-semibold text-ink",
						children: "Cancelar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "min-h-11 flex-1 rounded-xl bg-lagoon text-sm font-semibold text-on-lagoon hover:bg-lagoon-deep",
						children: "Guardar regla"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 border-t border-line pt-4",
			children: confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setConfirmReset(false),
					className: "min-h-11 flex-1 rounded-xl border border-line text-sm font-semibold text-ink",
					children: "Volver"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onReset,
					className: "min-h-11 flex-1 rounded-xl bg-danger text-sm font-semibold text-on-danger",
					children: "Sí, restablecer"
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setConfirmReset(true),
				className: "min-h-11 w-full text-sm font-semibold text-danger",
				children: "Restablecer a 200 y 70, y borrar movimientos"
			})
		})]
	});
}
function NumberField({ id, label, value, onChange }) {
	const n = /^\d+$/.test(value) ? Number(value) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium text-ink",
		htmlFor: id,
		children: [
			label,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id,
				inputMode: "numeric",
				value,
				onChange: (event) => onChange(event.target.value.replace(/\D/g, "").slice(0, 6)),
				className: "mt-1 h-11 w-full rounded-xl border border-line bg-card px-3 text-base text-ink tabular-nums"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1 block text-xs font-normal text-muted tabular-nums",
				children: n === null ? "Número entero" : `${formatQty(bottlesOf(n))} botellas`
			})
		]
	});
}
function ConfirmDialog({ title, body, confirmLabel, onClose, onConfirm }) {
	const [error, setError] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogShell, {
		title,
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: body
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-3 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "min-h-11 flex-1 rounded-xl border border-line bg-card text-sm font-semibold text-ink",
					children: "Cancelar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						const message = onConfirm();
						if (message) setError(message);
					},
					className: "min-h-11 flex-1 rounded-xl bg-danger text-sm font-semibold text-on-danger",
					children: confirmLabel
				})]
			})
		]
	});
}
function DialogShell({ title, children, onClose }) {
	const titleId = (0, import_react.useId)();
	const panelRef = (0, import_react.useRef)(null);
	const onCloseRef = (0, import_react.useRef)(onClose);
	onCloseRef.current = onClose;
	(0, import_react.useEffect)(() => {
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		(panelRef.current?.querySelector("input, button, textarea, select"))?.focus();
		const onKey = (event) => {
			if (event.key === "Escape") onCloseRef.current();
		};
		window.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = previous;
			window.removeEventListener("keydown", onKey);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 sm:items-center sm:p-4",
		onMouseDown: (event) => {
			if (event.target === event.currentTarget) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			ref: panelRef,
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": titleId,
			className: "max-h-dvh w-full overflow-y-auto rounded-t-2xl bg-card p-5 shadow-card sm:max-w-md sm:rounded-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				id: titleId,
				className: "text-2xl text-ink",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children
			})]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardexApp, {});
}
//#endregion
export { Home as component };
