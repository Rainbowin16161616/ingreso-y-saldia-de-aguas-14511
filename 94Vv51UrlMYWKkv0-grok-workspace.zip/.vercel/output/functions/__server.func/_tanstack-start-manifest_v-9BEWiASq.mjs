//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-9BEWiASq.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-Cfh1mpDT.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Cfh1mpDT.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes---O-ddt2.js"]
	}
} });
//#endregion
export { tsrStartManifest };
